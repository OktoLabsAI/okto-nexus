"""Packaged NXL contract resources."""
