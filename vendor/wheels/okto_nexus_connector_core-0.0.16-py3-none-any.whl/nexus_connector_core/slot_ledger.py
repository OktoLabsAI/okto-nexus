"""Installation-scoped durable owned-slot ledger shared across journals.

The trusted host must inject the same absolute local file path into every
Core instance belonging to one installation. A reservation is not proof that
its process is live; it remains occupied until the owning Core proves a
prelaunch refusal or observes stop through its native containment handle.
"""

from __future__ import annotations

from pathlib import Path
import secrets
import sqlite3
import time

from .offloop import (ExecutorClosed, ExecutorFull, OffLoopExecutor)
from .journal import validate_claim_namespace, validate_claim_page
from .models import (CoreError, OperationKey, OwnedSlotPage,
                     OwnedSlotReservation, OwnedSlotState, SessionKey)
from .capacity_storage import (SCHEMA as CAPACITY_SCHEMA, SQLiteCapacityOperations,
                               transfer_reserved_open, release_session_capacity, _changed)
from .journal_location_storage import (EMPTY_DIGEST, SCHEMA as JOURNAL_LOCATION_SCHEMA,
                                       SQLiteJournalLocationRegistry)


class SQLiteOwnedSlotLedger(SQLiteCapacityOperations, SQLiteJournalLocationRegistry):
    """A cross-process slot cap independent of per-executor journal files."""

    def __init__(self, path: str | Path, *, max_slots: int = 8,
                 max_storage_bytes: int = 512 * 1024 * 1024):
        path = Path(path)
        if not path.is_absolute():
            raise ValueError("owned-slot ledger needs an absolute local path")
        if (type(max_slots) is not int or not 1 <= max_slots <= 9223372036854775807 or
                type(max_storage_bytes) is not int or
                not 65536 <= max_storage_bytes <= 9223372036854775807):
            raise ValueError("invalid owned-slot ledger limits")
        self.path = path
        self.max_slots = max_slots
        self.max_storage_bytes = max_storage_bytes
        self._executor = OffLoopExecutor(name="core-slot-ledger-worker")
        self._storage_identity = None
        self._executor.start(self._open_database)

    def _open_database(self):
        """Worker-side setup: the connection lives on the executor thread."""
        db = sqlite3.connect(str(self.path), isolation_level=None, timeout=5)
        try:
            deadline = time.monotonic() + 5
            while True:
                try:
                    mode = db.execute("PRAGMA journal_mode=WAL").fetchone()[0]
                except sqlite3.OperationalError as exc:
                    busy = ((getattr(exc, "sqlite_errorcode", 0) or 0) & 0xFF) in {
                        sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED}
                    if not busy or time.monotonic() >= deadline:
                        raise
                    time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
                    continue
                if mode.lower() != "wal":
                    raise CoreError("JOURNAL_UNAVAILABLE", "slot_ledger_open")
                break
            db.execute("PRAGMA synchronous=FULL")
            page_size = db.execute("PRAGMA page_size").fetchone()[0]
            db.execute(
                f"PRAGMA max_page_count={max(1, self.max_storage_bytes // page_size)}")
            db.execute("PRAGMA wal_autocheckpoint=128")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS owned_slot_policy (
                    singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
                    max_slots INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS owned_slot_reservations (
                    server_id TEXT NOT NULL,
                    executor_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    operation_id TEXT NOT NULL,
                    released INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY(server_id, executor_id, session_id)
                );
                CREATE INDEX IF NOT EXISTS active_owned_slot_reservations
                    ON owned_slot_reservations(released);
            """)
            db.executescript(CAPACITY_SCHEMA)
            db.executescript(JOURNAL_LOCATION_SCHEMA)
            db.execute('BEGIN IMMEDIATE')
            try:
                identity = db.execute('SELECT store_id FROM managed_store_identity WHERE singleton=1').fetchone()
                if identity is None:
                    db.execute('INSERT INTO managed_store_identity(singleton,store_id) VALUES(1,?)',
                               ('store_' + secrets.token_hex(16),))
                elif (type(identity[0]) is not str or len(identity[0]) != 38
                      or not identity[0].startswith('store_')
                      or any(char not in '0123456789abcdef' for char in identity[0][6:])):
                    raise CoreError('JOURNAL_UNAVAILABLE', 'slot_ledger_open')
                head = db.execute('SELECT 1 FROM managed_journal_head WHERE singleton=1').fetchone()
                if head is None:
                    has_history = db.execute('SELECT 1 FROM managed_journal_locations LIMIT 1').fetchone()
                    db.execute('INSERT INTO managed_journal_head(singleton,revision,digest,complete) '
                               'VALUES(1,0,?,?)', (EMPTY_DIGEST, 0 if has_history else 1))
                progress = db.execute('SELECT 1 FROM managed_journal_extension_progress '
                    'WHERE singleton=1').fetchone()
                if progress is None:
                    current = db.execute('SELECT revision,complete FROM managed_journal_head '
                        'WHERE singleton=1').fetchone()
                    db.execute('INSERT INTO managed_journal_extension_progress '
                               '(singleton,revision,digest,complete) VALUES(1,0,?,?)',
                               (EMPTY_DIGEST, 1 if current == (0, 1) else 0))
                db.execute('COMMIT')
            except BaseException:
                self._rollback_if_active(db)
                raise
            info = self.path.stat()
            self._storage_identity = (info.st_dev, info.st_ino)
        except BaseException:
            db.close()
            raise
        return db
    async def _run(self, impl, *, urgent: bool = True):
        try:
            future = self._executor.submit(impl, urgent=urgent)
        except ExecutorFull as exc:
            raise CoreError("JOURNAL_BUSY", "slot_ledger",
                            retry_safe=True) from exc
        except ExecutorClosed as exc:
            raise CoreError("JOURNAL_CLOSED", "slot_ledger",
                            retry_safe=True) from exc
        return await future

    def _run_sync(self, work, *, timeout: float = 30.0):
        return self._executor.run_sync(work, timeout=timeout)

    async def aclose(self, *, timeout: float = 10.0) -> str:
        return await self._executor.aclose(timeout=timeout)

    def close(self) -> None:
        self._executor.close(timeout=15.0)

    def _check_storage_identity(self, db) -> None:
        try:
            info = self.path.stat()
        except OSError as exc:
            raise CoreError("JOURNAL_UNAVAILABLE", "slot_ledger") from exc
        if (info.st_dev, info.st_ino) != self._storage_identity:
            raise CoreError("PROFILE_DRIFT", "slot_ledger")

    @staticmethod
    def _validate(key: OperationKey, session_id: str) -> None:
        if not isinstance(key, OperationKey):
            raise ValueError("invalid owned-slot identity")
        validate_claim_namespace(key.server_id, key.executor_id)
        if (type(key.operation_id) is not str or not key.operation_id or
                type(session_id) is not str or not session_id):
            raise ValueError("invalid owned-slot identity")

    def _rollback_if_active(self, db) -> None:
        if db.in_transaction:
            db.execute("ROLLBACK")

    async def reserve_owned_slot(self, key: OperationKey,
                                 session_id: str, *, intent_hash: str | None = None) -> None:
        """Reserve before native launch; ambiguity leaves the slot pinned."""
        self._validate(key, session_id)

        def _worker_impl(db):
            self._check_storage_identity(db)
            db.execute("BEGIN IMMEDIATE")
            try:
                policy = db.execute(
                    "SELECT max_slots FROM owned_slot_policy WHERE singleton=1"
                ).fetchone()
                if policy is None:
                    db.execute(
                        "INSERT INTO owned_slot_policy VALUES (1,?)",
                        (self.max_slots,))
                elif policy[0] != self.max_slots:
                    raise CoreError("PROFILE_DRIFT", "slot_ledger")
                existing = db.execute(
                    """SELECT 1 FROM owned_slot_reservations
                       WHERE server_id=? AND executor_id=? AND session_id=?""",
                    (key.server_id, key.executor_id, session_id)).fetchone()
                if existing is not None:
                    if transfer_reserved_open(db, key, session_id, intent_hash):
                        db.execute("COMMIT")
                        return
                    raise CoreError("SESSION_CONFLICT", "slot_ledger",
                                    possible_effect=True)
                occupied = db.execute(
                    "SELECT COUNT(*) FROM owned_slot_reservations WHERE released=0"
                ).fetchone()[0]
                if occupied >= self.max_slots:
                    raise CoreError("CAPACITY_EXCEEDED", "slot_ledger",
                                    retry_safe=True, operation_id=key.operation_id)
                db.execute(
                    "INSERT INTO owned_slot_reservations VALUES (?,?,?,?,0)",
                    (key.server_id, key.executor_id, session_id,
                     key.operation_id))
                _changed(db)
                db.execute("COMMIT")
            except BaseException as exc:
                self._rollback_if_active(db)
                if (isinstance(exc, sqlite3.Error) and
                        getattr(exc, "sqlite_errorcode", None) == sqlite3.SQLITE_FULL):
                    raise CoreError("JOURNAL_FULL", "slot_ledger",
                                    retry_safe=True,
                                    operation_id=key.operation_id) from exc
                raise
        return await self._run(_worker_impl)

    async def release_owned_slot(self, key: OperationKey,
                                 session_id: str) -> bool:
        """Trusted caller releases only after non-effect or observed stop."""
        self._validate(key, session_id)

        def _worker_impl(db):
            self._check_storage_identity(db)
            db.execute("BEGIN IMMEDIATE")
            try:
                policy = db.execute(
                    "SELECT max_slots FROM owned_slot_policy WHERE singleton=1"
                ).fetchone()
                if policy is None or policy[0] != self.max_slots:
                    raise CoreError("PROFILE_DRIFT", "slot_ledger_release")
                row = db.execute(
                    """SELECT operation_id,released FROM owned_slot_reservations
                       WHERE server_id=? AND executor_id=? AND session_id=?""",
                    (key.server_id, key.executor_id, session_id)).fetchone()
                if row is None or row[0] != key.operation_id:
                    raise CoreError("SESSION_CONFLICT", "slot_ledger_release")
                if not row[1]:
                    db.execute(
                        """UPDATE owned_slot_reservations SET released=1
                           WHERE server_id=? AND executor_id=? AND session_id=?""",
                        (key.server_id, key.executor_id, session_id))
                    release_session_capacity(db, key.server_id, key.executor_id, session_id)
                    _changed(db)
                db.execute("COMMIT")
            except BaseException as exc:
                self._rollback_if_active(db)
                if (isinstance(exc, sqlite3.Error) and
                        getattr(exc, "sqlite_errorcode", None) == sqlite3.SQLITE_FULL):
                    raise CoreError("JOURNAL_FULL", "slot_ledger_release",
                                    possible_effect=True,
                                    operation_id=key.operation_id) from exc
                raise
            return not bool(row[1])
        return await self._run(_worker_impl)

    async def owned_slot_state(self, session: SessionKey) -> OwnedSlotState | None:
        """Read a specific durable fact; a missing row means no known record.

        Released reservations are retained across restarts. Release can mean
        proven non-effect or observed stop, so callers must also correlate the
        original opening receipt before interpreting session history.
        """
        if not isinstance(session, SessionKey):
            raise ValueError("Invalid owned-slot session.")
        validate_claim_namespace(session.server_id, session.executor_id)
        if type(session.session_id) is not str or not session.session_id:
            raise ValueError("Invalid owned-slot session.")

        def _worker_impl(db):
            self._check_storage_identity(db)
            policy = db.execute(
                "SELECT max_slots FROM owned_slot_policy WHERE singleton=1").fetchone()
            if policy is not None and policy[0] != self.max_slots:
                raise CoreError("PROFILE_DRIFT", "owned_slot_state")
            row = db.execute(
                "SELECT operation_id,released FROM owned_slot_reservations "
                "WHERE server_id=? AND executor_id=? AND session_id=?",
                (session.server_id, session.executor_id, session.session_id)).fetchone()
            if row is None:
                return None
            if type(row[0]) is not str or not row[0] or row[1] not in (0, 1):
                raise CoreError("JOURNAL_UNAVAILABLE", "owned_slot_state")
            return OwnedSlotState(session, row[0], bool(row[1]))
        return await self._run(_worker_impl, urgent=False)

    async def owned_slot_page(self, *, after_rowid: int = 0,
                              high_water_rowid: int | None = None,
                              limit: int = 128) -> OwnedSlotPage:
        """Read a bounded active-reservation page, not live process proof."""
        validate_claim_page(after_rowid, high_water_rowid, limit,
                            label="owned-slot")

        def _worker_impl(db, high_water_rowid=high_water_rowid):
            self._check_storage_identity(db)
            policy = db.execute(
                "SELECT max_slots FROM owned_slot_policy WHERE singleton=1"
            ).fetchone()
            if policy is not None and policy[0] != self.max_slots:
                raise CoreError("PROFILE_DRIFT", "slot_ledger_page")
            if high_water_rowid is None:
                high_water_rowid = db.execute(
                    "SELECT COALESCE(MAX(rowid),0) FROM owned_slot_reservations"
                ).fetchone()[0]
            rows = db.execute(
                """SELECT rowid,server_id,executor_id,session_id,operation_id
                   FROM owned_slot_reservations
                   WHERE released=0 AND rowid>? AND rowid<=?
                   ORDER BY rowid LIMIT ?""",
                (after_rowid, high_water_rowid, limit + 1)).fetchall()
            page_rows = rows[:limit]
            return OwnedSlotPage(
                tuple(OwnedSlotReservation(SessionKey(server_id, executor_id,
                                                      session_id), operation_id)
                      for _, server_id, executor_id, session_id,
                      operation_id in page_rows),
                high_water_rowid,
                page_rows[-1][0] if len(rows) > limit else None)
        return await self._run(_worker_impl)
