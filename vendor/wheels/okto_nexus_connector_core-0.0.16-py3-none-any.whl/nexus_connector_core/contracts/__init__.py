"""Packaged NXL contract resources."""
