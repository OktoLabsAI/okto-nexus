"""Send one admitted plain-text turn through the protected Claude terminal."""

import asyncio
import threading
import time

from ..models import CoreError, EffectNotSent, RuntimeEvent
from .redaction import NativeSecretRedactor

_WRITE_WINDOW = 10.0
_MAX_PASTE_BYTES = 64 * 1024 - len(b"\x1b[200~\x1b[201~\r")
_STAGE = "claude_terminal_submission"


class ClaudeTerminalSubmission:
    def __init__(self, terminal, prompt_gate):
        self._terminal = terminal
        self._gate = prompt_gate
        self._active_operation = None

    def active_turn(self):
        return self._active_operation is not None

    def confirm_terminal(self, operation_id):
        """Release this slot only when the exact terminal event is durable."""
        if operation_id == self._active_operation:
            self._active_operation = None

    async def submit(self, operation_id, text, verify):
        if self._active_operation is not None:
            raise EffectNotSent("The prior Claude terminal submission is unsettled.", code="STALE_TURN")
        paste = _terminal_prompt(text)
        if paste is None:
            raise EffectNotSent("Only bounded plain text can be sent as a prompt.", code="VALIDATION_ERROR")
        if not await verify():
            raise EffectNotSent("The durable Claude submission or its authority changed.", code="BINDING_NOT_AUTHORIZED")

        loop = asyncio.get_running_loop()
        deadline = time.monotonic() + _WRITE_WINDOW
        cancelled = threading.Event()

        def authorize_hook():
            if cancelled.is_set():
                return False
            future = asyncio.run_coroutine_threadsafe(verify(), loop)
            try:
                allowed = future.result(timeout=min(2.0, max(0, deadline - time.monotonic()))) is True
                return allowed and not cancelled.is_set()
            finally:
                if not future.done():
                    future.cancel()

        self._active_operation = operation_id
        armed = asyncio.create_task(asyncio.to_thread(self._gate.arm, operation_id, text,
                                                      ttl=_WRITE_WINDOW, check=authorize_hook))
        try:
            delivery = await asyncio.shield(armed)
        except CoreError as error:
            self._active_operation = None
            raise EffectNotSent("The terminal permit could not be installed.", code=error.code) from error
        except asyncio.CancelledError:
            cancelled.set()
            try:
                await armed
            finally:
                await asyncio.to_thread(self._gate.discard, operation_id)
            raise
        try:
            async with asyncio.timeout_at(loop.time() + max(0, deadline - time.monotonic())):
                await asyncio.to_thread(self._terminal.write, paste)
                acknowledged = await asyncio.to_thread(delivery.wait, max(0, deadline - time.monotonic()))
                if not acknowledged:
                    raise TimeoutError("Claude terminal submission did not receive a definitive hook reply.")
        except (CoreError, OSError, TimeoutError) as error:
            raise CoreError("OUTCOME_UNKNOWN", _STAGE, possible_effect=True, operation_id=operation_id) from error
        finally:
            cancelled.set()
            await asyncio.to_thread(self._gate.discard, operation_id)


def _terminal_prompt(text):
    if (type(text) is not str or not text.strip() or text.lstrip().startswith(("/", "!"))
            or len(text) > _MAX_PASTE_BYTES
            or any(char != "\n" and (char < " " or "\x7f" <= char <= "\x9f") for char in text)):
        return None
    try:
        data = text.encode("utf-8")
    except UnicodeError:
        return None
    if len(data) > _MAX_PASTE_BYTES:
        return None
    return b"\x1b[200~" + data + b"\x1b[201~\r"


class ClaudeTerminalSession:
    """Core's native session port for an exact, already verified Claude terminal."""

    def __init__(self, terminal, gate, *, native_id, session_id, stream_epoch, context, redactor, observe_finished):
        if not isinstance(redactor, NativeSecretRedactor):
            raise TypeError("An owned Claude terminal requires native secret redaction.")
        if not callable(observe_finished):
            raise TypeError("An owned Claude terminal requires an exact native completion observation.")
        self.native_id = native_id
        self._terminal = terminal
        self._gate = gate
        self._session_id = session_id
        self._stream_epoch = stream_epoch
        self._context = context
        self._redactor = redactor
        self._observe_finished = observe_finished
        self._close_lock = asyncio.Lock()
        self._closed = False
        self.terminal_submission = ClaudeTerminalSubmission(terminal, gate)

    def _completion_event(self, result):
        payload = {"delivery_phase": "terminal",
                   "delivery_outcome": "success" if result.failure_code is None else "failed"}
        if result.failure_code is None:
            payload["output_text"] = self._redactor.clean(result.output_text)
        else:
            payload["delivery_error_code"] = result.failure_code
        return RuntimeEvent(self._context.server_id, self._context.executor_id, self._session_id,
                            self._stream_epoch, 0, "turn_state",
                            "Stop" if result.failure_code is None else "StopFailure",
                            payload, operation_id=result.operation_id)

    async def events(self):
        while not self._closed and await asyncio.to_thread(self._terminal.poll) is None:
            result = await asyncio.to_thread(self._gate.take_finished_result, self._observe_finished)
            if result is not None:
                yield self._completion_event(result)
            await asyncio.sleep(0.1)

    def owned_process_birth(self):
        return self._terminal.birth

    async def send(self, _verb, _payload, _operation_id, *, expected_turn_id=None):
        raise EffectNotSent("This action is not available on the owned Claude terminal.")

    async def observe(self):
        if await asyncio.to_thread(self._terminal.poll) is not None:
            return "STOPPED", "UNKNOWN"
        return "RUNNING", "BUSY" if self.terminal_submission.active_turn() else "IDLE"

    async def close(self):
        async with self._close_lock:
            if self._closed:
                return "already_closed"
            prior_exit = await asyncio.to_thread(self._terminal.poll)
            await asyncio.to_thread(self._terminal.close)
            await asyncio.to_thread(self._gate.__exit__, None, None, None)
            self._closed = True
            return "graceful" if prior_exit == 0 else "forced"

    async def force_stop(self):
        await self.close()
