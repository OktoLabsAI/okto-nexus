"""Connection-scoped native-event redaction, adapted from Nexus.

Known child credentials are injected by the trusted host. Raw native text
fields never leave this boundary on output-delta events; safe normalized text
is delayed by a bounded holdback so secrets split across chunks are masked.
"""

from __future__ import annotations

from dataclasses import replace
import json
import re
from typing import Any, Iterable

from ..models import CoreError
from .adapter_types import HarnessEvent
from .codex_chat_facts import CODEX_CHAT_DELTA, MAX_CODEX_CHAT_BYTES, is_codex_chat_id

_MASK = "[REDACTED]"
_TEXT_MASK = "[NATIVE_TEXT_REDACTED]"
_SENSITIVE_KEY = re.compile(
    r"(?:^|_)(?:authorization|api_key|apikey|access_token|refresh_token|"
    r"id_token|password|secret|session_secret|credential|token)(?:$|_)", re.I)
_SENSITIVE_ENV = re.compile(r"(?:KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|AUTH)", re.I)
_GENERIC_SECRET = re.compile(
    r"(?:nxs_|nxsept_)[A-Za-z0-9_-]+|\bsk-[A-Za-z0-9_-]{12,}|"
    r"\bBearer\s+[^\s\"']+", re.I)
_GENERIC_PREFIX = re.compile(r"(?:nxs_|nxsept_|\bsk-|\bBearer\s+)", re.I)
_GENERIC_TRAILING_PREFIX = re.compile(
    "(?:" + "|".join(re.escape(stem[:length])
                      for stem in ("nxs_", "nxsept_", "sk-", "Bearer")
                      for length in range(1, len(stem) + 1)) + r")\Z", re.I,
)
_TOKEN_END = re.compile(r"[\s\"']")
_MAX_PENDING = 16 * 1024
_MAX_STREAMS = 64
from ..event_artifacts import MAX_PAYLOAD_BYTES
_MAX_NATIVE_EVENT_BYTES = MAX_PAYLOAD_BYTES


def _is_sensitive_key(key: str) -> bool:
    normalized = re.sub(r"[^a-z0-9]", "", key.lower())
    return bool(_SENSITIVE_KEY.search(key) or normalized.endswith((
        "authorization", "apikey", "accesstoken", "refreshtoken", "idtoken",
        "password", "secret", "credential", "token")))


def credential_values(environment: dict[str, str]) -> tuple[str, ...]:
    """Select only approved secret-looking child variables, never PATH/home."""
    return tuple(value for name, value in environment.items()
                 if _SENSITIVE_ENV.search(name) and isinstance(value, str) and value)


def _extract_output(event: HarnessEvent) -> str | None:
    if event.output_text is not None:
        return event.output_text
    if event.kind != "output_delta":
        return None
    payload = event.payload
    for value in (payload.get("delta"), payload.get("text"),
                  (payload.get("assistantMessageEvent") or {}).get("delta")
                  if isinstance(payload.get("assistantMessageEvent"), dict) else None):
        if isinstance(value, str):
            return value
    nested = payload.get("event")
    if isinstance(nested, dict):
        delta = nested.get("delta")
        if isinstance(delta, dict) and isinstance(delta.get("text"), str):
            return delta["text"]
    return None


class NativeSecretRedactor:
    version = 1

    def __init__(self, values: Iterable[str] = ()):
        selected = {value for value in values if isinstance(value, str) and value}
        if (len(selected) > 128 or any(len(value) > 16384 for value in selected)
                or sum(map(len, selected)) > 65536):
            raise CoreError("CAPACITY_EXCEEDED", "native_redaction")
        variants = set(selected)
        for value in selected:
            variants.update((json.dumps(value, ensure_ascii=False)[1:-1],
                             json.dumps(value, ensure_ascii=True)[1:-1],
                             repr(value)[1:-1]))
        self._variants = tuple(sorted(variants, key=len, reverse=True))
        self._known = (re.compile("|".join(map(re.escape, self._variants)))
                       if variants else None)
        self._holdback = max(8, max(map(len, variants), default=1) - 1)
        self._pending: dict[tuple[str, str | None, str | None], str] = {}
        self._codex_chat_pending: dict[tuple[str, str, str, str], str] = {}

    def clean(self, value: Any) -> Any:
        if isinstance(value, dict):
            return {self.clean(key): (_MASK if isinstance(key, str) and
                    _is_sensitive_key(key) else self.clean(item))
                    for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [self.clean(item) for item in value]
        if isinstance(value, str):
            if self._known is not None:
                value = self._known.sub(_MASK, value)
            return _GENERIC_SECRET.sub(_MASK, value)
        return value

    def _withhold_raw_text(self, value: Any) -> Any:
        if isinstance(value, dict):
            return {key: self._withhold_raw_text(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [self._withhold_raw_text(item) for item in value]
        if isinstance(value, str):
            return _TEXT_MASK
        return value

    def _split(self, text: str, *, final: bool) -> tuple[str, str]:
        if final:
            return self.clean(text), ""
        return self._split_at(text, max(0, len(text) - self._holdback))

    def release_text_tail(self, text: str) -> tuple[str, str]:
        """Release idle plaintext while keeping any possible partial secret."""
        partial = _GENERIC_TRAILING_PREFIX.search(text)
        cut = partial.start() if partial else len(text)
        for value in self._variants:
            # A partial match must start within a proper prefix length of the end.
            start = text.find(value[0], max(0, len(text) - len(value) + 1), cut)
            while start != -1:
                if value.startswith(text[start:]):
                    cut = start
                    break
                start = text.find(value[0], start + 1, cut)
        return self._split_at(text, cut)

    def _split_at(self, text: str, cut: int) -> tuple[str, str]:
        if self._known is not None:
            for match in self._known.finditer(text):
                if match.start() < cut < match.end():
                    cut = match.start()
                    break
        for match in _GENERIC_PREFIX.finditer(text):
            end = _TOKEN_END.search(text, match.end())
            if match.start() < cut and (end is None or end.start() >= cut):
                cut = match.start()
                break
        return self.clean(text[:cut]), text[cut:]

    def _codex_chat_delta(self, event: HarnessEvent, *, final: bool) -> dict | None:
        # The generic execution output also carries other native output types.
        # Its pending bytes cannot establish which chat item owns the text.
        pending = self._codex_chat_pending
        if final:
            for key in tuple(pending):
                if key[0] == event.session_id:
                    del pending[key]
            return None
        thread, turn = event.thread_id, event.turn_id
        payload = event.payload
        if (thread != payload.get("threadId") or turn != payload.get("turnId")
                or not all(is_codex_chat_id(value) and self.clean(value) == value for value in (thread, turn))):
            return None
        if event.native_event == "item/completed":
            item = payload.get("item")
            if isinstance(item, dict) and item.get("type") == "agentMessage" and is_codex_chat_id(item.get("id")):
                # The completed item supplies a full, separately redacted snapshot.
                pending.pop((event.session_id, thread, turn, item["id"]), None)
            return None
        if (event.native_event != "item/agentMessage/delta" or event.kind != "output_delta"
                or event.output_snapshot or event.operation_id is None):
            return None
        item, delta = payload.get("itemId"), payload.get("delta")
        if not is_codex_chat_id(item) or self.clean(item) != item or not isinstance(delta, str):
            return None
        key = (event.session_id, thread, turn, item)
        safe, tail = self._split(pending.pop(key, "") + delta, final=False)
        self._retain_tail(pending, key, tail)
        if not safe:
            return None
        encoded = safe.encode("utf-8")
        return {"revision": 1, "thread_id": thread, "item_id": item,
                "text": encoded[:MAX_CODEX_CHAT_BYTES].decode("utf-8", errors="ignore"),
                "truncated": len(encoded) > MAX_CODEX_CHAT_BYTES}

    @staticmethod
    def _retain_tail(pending: dict, key: tuple, tail: str) -> None:
        if tail:
            if len(pending) >= _MAX_STREAMS or len(tail) > _MAX_PENDING:
                raise CoreError("CAPACITY_EXCEEDED", "native_redaction")
            pending[key] = tail

    def scrub(self, event: HarnessEvent) -> HarnessEvent:
        if len(json.dumps(event.payload, ensure_ascii=False, default=str).encode("utf-8")) > _MAX_NATIVE_EVENT_BYTES:
            raise CoreError("EVENT_TOO_LARGE", "native_redaction")
        payload = self.clean(event.payload)
        output = _extract_output(event)
        key = (event.session_id, event.thread_id, event.turn_id)
        final = event.delivery_phase == "terminal" or event.kind == "turn_completed"
        if event.kind == "output_delta":
            payload = self._withhold_raw_text(payload)
        payload.pop(CODEX_CHAT_DELTA, None)
        if event.harness_kind == "codex":
            chat = self._codex_chat_delta(event, final=final)
            if chat is not None:
                payload[CODEX_CHAT_DELTA] = chat
        if output is not None or final:
            pending = self._pending.pop(key, "")
            prior = "" if event.output_snapshot else pending
            if final and not prior and output is None:
                tails = [self._pending.pop(other) for other in tuple(self._pending)
                         if other[0] == event.session_id]
                prior = "".join(tails)
            output, tail = self._split(prior + (output or ""), final=final)
            self._retain_tail(self._pending, key, tail)
        return replace(event, payload=payload, output_text=output,
                       native_approval=self.clean(event.native_approval))
