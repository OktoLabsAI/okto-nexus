"""Small immutable, application-neutral public data types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping


class CoreError(Exception):
    def __init__(self, code: str, stage: str, *, possible_effect: bool = False,
                 retry_safe: bool = False, operation_id: str | None = None,
                 message: str | None = None):
        # C3/S07: ``code`` stays a stable machine-readable enum;
        # ``message`` carries human diagnostics (redacted by the raiser)
        # without being concatenated into the classification field.
        super().__init__(message if message is not None else code)
        self.code = code
        self.stage = stage
        self.possible_effect = possible_effect
        self.retry_safe = retry_safe
        self.operation_id = operation_id
        self.message = message if message is not None else code


class EffectNotSent(Exception):
    """The native command was rejected before any effect-capable write."""

    def __init__(self, message: str, *, code: str = "CAPABILITY_UNSUPPORTED"):
        super().__init__(message)
        self.code = code


class EffectRejected(Exception):
    """A correlated native reply confirms rejection after a protocol write."""

    def __init__(self, message: str, *, failure_code: str = "NATIVE_OPERATION_FAILED"):
        super().__init__(message)
        self.failure_code = failure_code


@dataclass(frozen=True, slots=True)
class ControlTargeting:
    """Implemented control shape, never a grant or provider qualification."""

    action: str
    supported: bool
    native_turn_id: str  # required | optional | forbidden
    requires_active_run: bool
    steer_timing: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {"action": self.action, "supported": self.supported,
                "native_turn_id": self.native_turn_id,
                "requires_active_run": self.requires_active_run,
                "steer_timing": self.steer_timing}


@dataclass(frozen=True, slots=True)
class R4Authority:
    """Additional immutable scope of a Core-installed R4 lease."""

    session_id: str
    workspace_binding_id: str
    binding_revision: int
    credential_epoch: int
    grant_id: str
    lease_id: str
    lease_serial: int
    connection_id: str
    boot_id: str


@dataclass(frozen=True, slots=True)
class ExecutionContext:
    server_id: str
    executor_id: str
    binding_id: str
    agent_id: str
    workspace_id: str
    authorization_revision: int
    configuration_revision: int
    connection_generation: int
    lease_deadline_monotonic: float
    allowed_actions: frozenset[str]
    session_owner_generation: int = 1
    r4_authority: R4Authority | None = None


@dataclass(frozen=True, slots=True)
class R4LeaseApplication:
    context: ExecutionContext
    acknowledgement: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class Operation:
    operation_id: str
    session_id: str
    action: str
    payload: Mapping[str, Any] = field(default_factory=dict)
    expected_turn_id: str | None = None


@dataclass(frozen=True, slots=True)
class OperationReceipt:
    operation_id: str
    intent_hash: str
    stage: str
    possible_effect: bool
    retry_safe: bool
    session_id: str
    native_id: str | None = None
    error_code: str | None = None


class OperationNotAdmitted(CoreError):
    """A correlated pre-effect refusal that is NOT a durable Core receipt.

    The host must durably retain ``refusal`` before publishing it. Core has
    admitted no operation and has consumed no containment reserve. A host
    that loses this exception before persisting it must reconcile normally.
    """

    def __init__(self, refusal: OperationReceipt):
        super().__init__(refusal.error_code, 'admission', retry_safe=True,
                         operation_id=refusal.operation_id)
        self.refusal = refusal


class OperationCapacityDeferred(CoreError):
    """Exact pre-journal capacity refusal; the same operation may wait.

    Emitted only by Core admission gates before an effect. This is not a
    receipt, execution or completion. Hosts retain their transport ownership
    and must release worker/session locks while waiting.
    """
    def __init__(self, key, session_id, digest):
        super().__init__('CAPACITY_EXCEEDED', 'capacity_admission', retry_safe=True,
                         operation_id=key.operation_id)
        self.key, self.session_id, self.intent_hash = key, session_id, digest

    def require_binding(self, binding):
        from .receipt_binding_r4 import validate_r4_receipt_binding
        value = validate_r4_receipt_binding(binding)
        source = value['source']
        if ((source['server_id'], source['executor_id'], source['operation_id'], source['session_id']) !=
                (self.key.server_id, self.key.executor_id, self.key.operation_id, self.session_id)
                or value['core_intent_hash'] != self.intent_hash):
            raise CoreError('OPERATION_CONFLICT', 'capacity_deferral')
        return value

    def stopped_receipt(self):
        """Host stopped while retaining this proven pre-effect refusal."""
        return OperationReceipt(self.key.operation_id, self.intent_hash, 'FAILED', False, True,
                                self.session_id, error_code='RUNTIME_DRAINING')


@dataclass(frozen=True, slots=True)
class OperationKey:
    server_id: str
    executor_id: str
    operation_id: str


@dataclass(frozen=True, slots=True)
class SessionKey:
    server_id: str
    executor_id: str
    session_id: str


@dataclass(frozen=True, slots=True)
class ClaimedSession:
    key: SessionKey
    opening_operation_id: str
    opening_connection_generation: int | None = None
    opening_owner_generation: int | None = None


@dataclass(frozen=True, slots=True)
class SessionLeaseState:
    """Durable last-known lease fence for one claimed session.

    Historical CAS evidence written with the session claim and updated by
    `renew_lease`/`revoke_lease`. It is not process liveness, not a lease
    deadline and not takeover authority.
    """

    key: SessionKey
    connection_generation: int
    owner_generation: int
    authorization_revision: int
    configuration_revision: int
    revoked: bool


@dataclass(frozen=True, slots=True)
class SessionClaimPage:
    claims: tuple[ClaimedSession, ...]
    high_water_rowid: int
    next_after_rowid: int | None


@dataclass(frozen=True, slots=True)
class OwnedSlotReservation:
    key: SessionKey
    opening_operation_id: str


@dataclass(frozen=True, slots=True)
class OwnedSlotState:
    """Historical reservation/release fact, never live process authority."""

    key: SessionKey
    opening_operation_id: str
    released: bool


@dataclass(frozen=True, slots=True)
class OwnedSlotPage:
    reservations: tuple[OwnedSlotReservation, ...]
    high_water_rowid: int
    next_after_rowid: int | None


@dataclass(frozen=True, slots=True)
class ProcessBirthEvidence:
    """Historical OS identity of a Core-owned container, never PID authority."""

    platform: str
    pid: int
    birth_token: str
    containment: str
    container_id: str | None = None


@dataclass(frozen=True, slots=True)
class ProcessBirthRecord:
    key: SessionKey
    opening_operation_id: str
    evidence: ProcessBirthEvidence


@dataclass(frozen=True, slots=True)
class ProcessBirthObservation:
    """Transient PID observation; no process-control or lease authority."""

    record: ProcessBirthRecord | None
    state: str


@dataclass(frozen=True, slots=True)
class RuntimeEvent:
    server_id: str
    executor_id: str
    session_id: str
    stream_epoch: str
    sequence: int
    category: str
    native_type: str | None
    payload: Mapping[str, Any]
    operation_id: str | None = None


@dataclass(frozen=True, slots=True)
class EventCursor:
    server_id: str
    executor_id: str
    session_id: str
    stream_epoch: str
    after_sequence: int = 0


@dataclass(frozen=True, slots=True)
class StorageStatus:
    database_bytes: int
    wal_bytes: int
    shm_bytes: int
    page_size: int
    page_count: int
    free_pages: int
    max_bytes: int

    @property
    def total_bytes(self) -> int:
        return self.database_bytes + self.wal_bytes + self.shm_bytes


@dataclass(frozen=True, slots=True)
class RuntimeSnapshot:
    session_id: str
    process_state: str
    turn_state: str
    ownership: str
    last_sequence: int
    lease_state: str = "UNKNOWN"
    connection_generation: int | None = None
    session_owner_generation: int | None = None


@dataclass(frozen=True, slots=True)
class InstallationCandidate:
    adapter_id: str
    executable: str
    fingerprint: str
    source: str
    trust: str
    version: str | None = None
    architecture: str | None = None
    launch_script: str | None = None
    # PC09: portable, path-free identity of the build content. The
    # path-bound ``fingerprint`` remains the local binding proof.
    build_identity: str | None = None
    # C11/A11-01: opaque ref of the SELECTABLE LOCAL INSTALLATION
    # (canonical executable + launch script; ``installation.py``).
    # Byte-identical copies in distinct locations are distinct
    # installations: distinct refs, same build identity.
    installation_ref: str | None = None
    # #67: why an untrusted candidate is not selected (resolved path and
    # trusted roots). Informational only; it never changes the trust rule.
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class HarnessSettings:
    effort: str | None = None
    provider: str | None = None
    approval_policy: str | None = None
    sandbox: str | None = None
    permission_mode: str | None = None
    user_input: str | None = None
    inherit_global_mcps: str | None = None


@dataclass(frozen=True, slots=True)
class LaunchIntent:
    agent_id: str
    workspace_id: str
    adapter_id: str
    mode: str = "managed"
    model: str | None = None
    auth_refs: tuple[str, ...] = ()
    harness_settings: HarnessSettings = field(default_factory=HarnessSettings)
    mcp_preset: tuple[dict, ...] = ()


@dataclass(frozen=True, slots=True)
class PreparedLaunch:
    intent: LaunchIntent
    candidate: InstallationCandidate
    argv: tuple[str, ...]
    cwd: str
    requested_root: str
    root_fingerprint: str
    profile_fingerprint: str
    secret_refs: tuple[str, ...]
    sandbox_applied: bool = False


@dataclass(frozen=True, slots=True)
class DiscoveryRequest:
    # C9/C01: None asks the CATALOG which adapters admit discovery on
    # this host (managed executables) - the caller never needs its own
    # adapter array; an explicit tuple remains a filter; () is "none".
    adapter_ids: tuple[str, ...] | None = None


@dataclass(frozen=True, slots=True)
class Inventory:
    candidates: tuple[InstallationCandidate, ...]


@dataclass(frozen=True, slots=True)
class OpenOperation:
    operation_id: str
    session_id: str
    stream_epoch: str
    prepared: PreparedLaunch


@dataclass(frozen=True, slots=True)
class CodexResumeGrant:
    """Trusted-host proof for binding one stored Codex thread to one open.

    C2/R09: this is the PUBLIC resume contract. Hosts construct it from
    ``nexus_connector_core`` and the copied-adapter bridge validates the
    exact type plus every binding field; a structural look-alike is not
    accepted. All fields come from the trusted host's own verification
    of the persisted rollout.
    """

    thread_id: str
    session_id: str
    server_id: str
    executor_id: str
    binding_id: str
    agent_id: str
    workspace_id: str
    session_owner_generation: int
    candidate_fingerprint: str
    root_fingerprint: str
    profile_fingerprint: str
    terminal_observed: bool
    persisted_rollout_observed: bool
    exclusive_owner: bool


@dataclass(frozen=True, slots=True)
class TurnOperation:
    operation_id: str
    session_id: str
    text: str
    expected_turn_id: str | None = None


@dataclass(frozen=True, slots=True)
class ControlOperation:
    operation_id: str
    session_id: str
    verb: str
    text: str | None = None
    expected_turn_id: str | None = None
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class NativeApprovalOperation:
    operation_id: str
    session_id: str
    request: Mapping[str, Any]
    decision: str
    operator_response: Mapping[str, Any] | None = None






@dataclass(frozen=True, slots=True)
class CloseOperation:
    operation_id: str
    session_id: str
    reason: str | None = None
    policy: ShutdownPolicy | None = None


@dataclass(frozen=True, slots=True)
class ReconcileRequest:
    server_id: str
    executor_id: str
    operation_ids: tuple[str, ...] = ()
    session_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ReconcileReport:
    receipts: tuple[OperationReceipt | None, ...]
    snapshots: tuple[RuntimeSnapshot, ...]


@dataclass(frozen=True, slots=True)
class ShutdownPolicy:
    drain_seconds: float = 30.0
    interrupt_seconds: float = 15.0


@dataclass(frozen=True, slots=True)
class ShutdownReport:
    session_outcomes: Mapping[SessionKey, str]
